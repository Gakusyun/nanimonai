public class KY6_4 {
    public static void main(String[] args) {
        System.out.println(Math.abs(-5.8));
        System.out.println(Math.ceil(3.2));
        System.out.println(Math.floor(3.8));
        System.out.println(Math.round(3.8));
        System.out.println(Math.round(3.2));
        System.out.println(Math.min(3, 2));
        System.out.println(Math.max(Math.PI, 4));
        System.out.println(Math.log(7.0));
        System.out.println(Math.pow(7, 2));
        System.out.println(Math.exp(0.4));
        System.out.println("e is:" + Math.E);
        System.out.println("π is:" + Math.PI);
        System.out.println(Math.random());
    }
}
